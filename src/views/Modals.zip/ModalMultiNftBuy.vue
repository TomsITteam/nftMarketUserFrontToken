<template>
  <b-modal id="bv-modal-multinft-buy" hide-footer>
    <template #modal-title>
      NFT {{ $t('nft.quantity_buy') }}
    </template>
    <b-form @submit.prevent="submit">
      <label class="sign__label">{{ $t('nft.buy_quantity') }} ({{ $t('nft.max') }} {{ this.sellerData.sell_amount }})</label>
      <b-input type="number" required class="sign__input mb-1 border" v-model="formData.amount"/>

      <p class="text-danger pl-2 pt-0 mt-0 mb-0" v-if="lackBalance">{{ $t('nft.insufficient_balance') }}</p>
      <label class="sign__label mb-4 pl-2">{{ toFixed(price,4) }} {{ (!sellerData.token?$env.VUE_APP_BASE_MAINNET:sellerData.token.symbol) }}<span v-if="!sellerData.token"> ≈ ￦{{ amountToPrice(price) }}</span></label>

      <b-button v-if="showAllow" variant="primary" class="height-50 base-font-weight mt-2 mb-4 w-100" block type="submit" @click="approve(sellerData.token.tokenAddress,$env.VUE_APP_MULTINFT_CONTRACT_ADDRESS )">
        <b-spinner v-if="loadingApprove"></b-spinner>
        <span v-else>{{ $t('nft.approve') }}</span>
      </b-button>
      <b-button v-else variant="primary" class="height-50 base-font-weight mt-2 mb-4 w-100" block type="submit" v-bind:class="{ disabled : isDisabled }">
        <b-spinner v-if="loading"></b-spinner>
        <span v-else>{{ $t('nft.buy') }}</span>
      </b-button>
    </b-form>
  </b-modal>
</template>

<script>
import tokenAllow from "../../mixins/tokenAllow";

export default {
  name: "ModalMultiNftBuy",
  mixins:[tokenAllow],
  props:{
    nftData : Object,
    sellerData : Object,
    updateNftData : Function
  },
  computed:{
    lackBalance(){
      this.setBalance()

      if(!this.sellerData.token || (!!this.sellerData.token && this.sellerData.token.tokenAddress == "0x0000000000000000000000000000000000000000")){
        if(this.price > this.balance) {
          return true
        }
      }else if(!!this.sellerData.token ){
        if(this.price > this.toUint(this.tokenBalance,this.sellerData.token.decimals)){
          console.log("asdasdasd2")
          return true
        }
      }

      return false
    },
    price(){
      if(this.sellerData.price == undefined){
        return 0
      }

      return this.sellerData.price * this.formData.amount
    },
    isDisabled(){
      if(this.loading == true){
        return true
      }else if(this.formData.amount <= 0){
        return true
      }else if(this.showAllow == true){
        return true
      }else if(this.lackBalance == true){
        return true
      }

      return false
    }
  },
  watch:{
    sellerData(val){
      if(!val.token){
        this.showAllow = false
        return
      }
      //토큰 결제의 경우 승인,잔액 체크
      this.updateAllow(val.token.tokenAddress,this.$env.VUE_APP_MULTINFT_CONTRACT_ADDRESS)
      this.updateBalance(val.token.tokenAddress)
    }
  },
  data(){
    return {
      loading : false,
      formData : {
        amount : 0
      },
      balance : 0,
      showAllow : false,
    }
  },
  methods:{
    async submit(){
      if(this.isDisabled == true){
        return
      }
      let senderValue = this.toFixed(this.formData.amount * this.sellerData.price,8)

      this.loading = true

      let txHash
      if(this.sellerData.token.tokenAddress != "0x0000000000000000000000000000000000000000"){
        //ERC20,BEP20,KIP7 토큰 결제
        txHash = await this.$contract.multiNFT.buy(this.nftData.token_id,this.sellerData.address,this.formData.amount,0)
      }else{
        txHash = await this.$contract.multiNFT.buy(this.nftData.token_id,this.sellerData.address,this.formData.amount,senderValue)
      }

      this.loading = false

      this.$bvModal.hide("bv-modal-multinft-buy")
    },
    async setBalance(){
      this.balance = (await this.$wallet.getBalance(this.$wallet.getAccount())) / 1000000000000000000
    },
  }
}
</script>

<style scoped>

</style>
